# Aether 2050 — Redmi 13 Pro+ 5G için fütüristik launcher

Kotlin + Jetpack Compose ile yazılmış, hafif ve hızlı bir Android ana ekran uygulaması.

## Özellikler
- **iOS tarzı dock**: ekranın en altında, ortalanmış, yüzen neon kenarlı cam dock (en fazla 5 uygulama)
- **2050 tasarımı**: nebula arka plan, neon perspektif ızgara, buzlu cam yüzeyler, degrade dev saat
- **4 tema rengi**: Kuantum, Plazma, Aurora, Solar
- **Sayfalı ana ekran** (4×5) ve hafif 3B küp geçiş efekti
- **Uygulama çekmecesi**: yukarı kaydır → parmağı takip eden, arkası bulanık panel; Türkçe A–Z bölümler, akıllı öneriler, anında arama, sonuç yoksa web araması
- **Hareketler**: aşağı kaydır → bildirimler, simgeye uzun bas → dock'a sabitle / bilgi / kaldır, saate dokun → alarm, saate uzun bas → ayarlar
- **Hız**: simgeler paralel yüklenir ve GPU bitmap olarak önbelleğe alınır, çekmece önceden hazırdır, release derlemesi R8 ile küçültülür

## APK nasıl alınır (bilgisayarsız, GitHub ile)
1. github.com'da yeni bir depo oluştur.
2. Bu klasördeki **tüm dosyaları klasör yapısını koruyarak** yükle (`.github/workflows/build.yml` dahil).
3. Depoda **Actions** sekmesi → "APK Derle" işi otomatik çalışır (~5 dk).
4. Bitince işin sayfasındaki **Artifacts → Aether2050-APK** dosyasını indir, zip'i aç, APK'yı telefona kur.

## Bilgisayarda Android Studio ile
Klasörü Android Studio'da aç → **Build › Generate APK** (veya terminalde `./gradlew assembleRelease`).
APK: `app/build/outputs/apk/release/app-release.apk`

## Redmi / HyperOS'ta varsayılan yapmak
Ayarlar › Uygulamalar › Varsayılan uygulamalar › Ana ekran › **Aether 2050**.
(Uygulama içindeki ayarlarda "Varsayılan başlatıcı yap" butonu da bu ekrana götürür.)

> Not: HyperOS bazı sürümlerde üçüncü parti launcher'larda hareketli navigasyonu (gesture) kısıtlayabilir;
> bu durumda sistem 3 tuşlu navigasyona geçmenizi isteyebilir.
