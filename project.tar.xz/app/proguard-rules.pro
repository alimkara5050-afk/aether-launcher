# Aether 2050 – ek kural gerekmiyor.
# Bildirim panelini açmak için kullanılan StatusBarManager bir sistem sınıfıdır, R8 dokunmaz.
