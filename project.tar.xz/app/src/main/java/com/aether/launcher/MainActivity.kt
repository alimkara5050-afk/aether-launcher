package com.aether.launcher

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.app.SearchManager
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.AlarmClock
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.mutableIntStateOf
import com.aether.launcher.data.AppInfo
import com.aether.launcher.ui.LauncherActions
import com.aether.launcher.ui.LauncherRoot

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()

    /** Ana ekran tuşuna her basılışta artar: çekmeceyi kapatır / ilk sayfaya döner. */
    private val homeTick = mutableIntStateOf(0)

    private val actions by lazy {
        LauncherActions(
            launch = ::launchApp,
            appInfo = { app ->
                safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
            },
            uninstall = { app ->
                safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
            },
            expandNotifications = ::expandNotifications,
            webSearch = { q ->
                val ok = safeStart(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                if (!ok) safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            },
            openClock = { safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)) },
            openHomeSettings = {
                if (!safeStart(Intent(Settings.ACTION_HOME_SETTINGS))) {
                    safeStart(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                }
            },
            openWallpaperPicker = {
                safeStart(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Duvar kâğıdı seç"))
            },
            toast = { msg -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() },
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        setContent {
            LauncherRoot(vm = vm, homeTick = homeTick.intValue, actions = actions)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (Intent.ACTION_MAIN == intent.action && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeTick.intValue++
        }
    }

    private fun launchApp(app: AppInfo, bounds: Rect?) {
        val launcherApps = getSystemService(LauncherApps::class.java)
        // Simgenin olduğu yerden büyüyerek açılma animasyonu (iOS hissi)
        val options = bounds?.takeIf { !it.isEmpty }?.let {
            ActivityOptions.makeScaleUpAnimation(window.decorView, it.left, it.top, it.width(), it.height()).toBundle()
        }
        try {
            launcherApps.startMainActivity(app.component, Process.myUserHandle(), bounds, options)
            vm.recordLaunch(app)
        } catch (e: Exception) {
            Toast.makeText(this, "Açılamadı: ${app.label}", Toast.LENGTH_SHORT).show()
            vm.refresh()
        }
    }

    private fun safeStart(intent: Intent): Boolean = try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    @SuppressLint("WrongConstant", "PrivateApi")
    private fun expandNotifications() {
        try {
            val service = getSystemService("statusbar") ?: return
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel")
                .invoke(service)
        } catch (_: Throwable) {
        }
    }
}
