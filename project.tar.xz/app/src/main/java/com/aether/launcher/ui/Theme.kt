package com.aether.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import java.util.Locale

internal val TR: Locale = Locale.forLanguageTag("tr-TR")

@Immutable
data class AccentPalette(
    val name: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
)

val Palettes = listOf(
    AccentPalette("Kuantum", Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF2E93)),
    AccentPalette("Plazma", Color(0xFFFF2E93), Color(0xFFFF8A00), Color(0xFF7C4DFF)),
    AccentPalette("Aurora", Color(0xFF00FFA3), Color(0xFF00B8FF), Color(0xFF7C4DFF)),
    AccentPalette("Solar", Color(0xFFFFD166), Color(0xFFEF476F), Color(0xFF00E5FF)),
)

val LocalAccent = compositionLocalOf { Palettes[0] }

@Composable
fun AetherTheme(accent: AccentPalette, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent.primary,
        onPrimary = Color(0xFF05060F),
        secondary = accent.secondary,
        tertiary = accent.tertiary,
        background = Color(0xFF05060F),
        surface = Color(0xFF0E1024),
        surfaceContainer = Color(0xFF131531),
        surfaceContainerHigh = Color(0xFF181A3A),
        onSurface = Color(0xFFEAF2FF),
        onSurfaceVariant = Color(0xFFA8B3CF),
    )
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(18.dp),
        small = RoundedCornerShape(16.dp),
        medium = RoundedCornerShape(22.dp),
        large = RoundedCornerShape(28.dp),
        extraLarge = RoundedCornerShape(32.dp),
    )
    MaterialTheme(colorScheme = scheme, shapes = shapes) {
        CompositionLocalProvider(LocalAccent provides accent, content = content)
    }
}

/** Neon kenarlı buzlu cam yüzey. intensity 0.5–1.3 aralığında kullanılır. */
fun Modifier.glass(shape: Shape, accent: AccentPalette, intensity: Float = 1f): Modifier {
    val k = intensity.coerceIn(0f, 1.5f)
    return this
        .clip(shape)
        .background(Color(0xFF080A1C).copy(alpha = (0.38f * k).coerceAtMost(1f)), shape)
        .background(
            Brush.verticalGradient(
                listOf(
                    Color.White.copy(alpha = (0.15f * k).coerceAtMost(1f)),
                    Color.White.copy(alpha = (0.04f * k).coerceAtMost(1f)),
                )
            ),
            shape,
        )
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    accent.primary.copy(alpha = 0.75f),
                    Color.White.copy(alpha = 0.10f),
                    accent.secondary.copy(alpha = 0.65f),
                )
            ),
            shape,
        )
}
