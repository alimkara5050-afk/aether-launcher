package com.aether.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.launcher.LauncherViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTextApi::class)
@Composable
fun SettingsSheet(vm: LauncherViewModel, actions: LauncherActions, onDismiss: () -> Unit) {
    val accent = LocalAccent.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xF20B0C1D),
        contentColor = Color.White,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "Aether 2050",
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(Color.White, accent.primary, accent.secondary)),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 1.sp,
                ),
            )

            SectionLabel("TEMA RENGİ")
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Palettes.forEachIndexed { i, p ->
                    PaletteDot(p, selected = i == vm.accentIndex) { vm.updateAccent(i) }
                }
            }

            SectionLabel("GÖRÜNÜM")
            SettingRow(
                title = "Sistem duvar kâğıdı",
                subtitle = "Kapalıyken 2050 nebula arka planı kullanılır",
                checked = vm.useSystemWallpaper,
                onChange = vm::updateWallpaper,
            )
            if (vm.useSystemWallpaper) {
                GlassButton("Duvar kâğıdı seç", actions.openWallpaperPicker)
            }
            SettingRow(
                title = "Uygulama adları",
                subtitle = "Ana ekranda simge adlarını göster",
                checked = vm.showLabels,
                onChange = vm::updateLabels,
            )

            GlassButton("Varsayılan başlatıcı yap", actions.openHomeSettings)

            Text(
                text = "Yukarı kaydır → tüm uygulamalar\nAşağı kaydır → bildirimler\nSimgeye uzun bas → dock'a sabitle / kaldır\nSaate dokun → alarm · uzun bas → bu ayarlar",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 12.sp,
                lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = LocalAccent.current.primary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
    )
}

@Composable
private fun PaletteDot(palette: AccentPalette, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(palette.primary, palette.secondary, palette.tertiary)))
                .then(
                    if (selected) Modifier.border(3.dp, Color.White, CircleShape)
                    else Modifier.border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                )
                .clickable(onClick = onClick)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            palette.name,
            fontSize = 11.sp,
            color = if (selected) Color.White else Color.White.copy(alpha = 0.6f),
        )
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(22.dp), accent, 0.8f)
            .clickable { onChange(!checked) }
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = Color.White)
            Text(subtitle, fontSize = 12.sp, color = Color.White.copy(alpha = 0.55f))
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF05060F),
                checkedTrackColor = accent.primary,
                uncheckedThumbColor = Color.White.copy(alpha = 0.8f),
                uncheckedTrackColor = Color.White.copy(alpha = 0.12f),
                uncheckedBorderColor = Color.White.copy(alpha = 0.25f),
            ),
        )
    }
}

@Composable
private fun GlassButton(text: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .glass(RoundedCornerShape(26.dp), accent, 1.1f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
