package com.aether.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Process
import android.provider.MediaStore
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

@Immutable
data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: ImageBitmap,
) {
    val key: String get() = component.flattenToString()
    val packageName: String get() = component.packageName
}

/**
 * Uygulama listesini ve simgeleri yükler.
 * - Simgeler paralel yüklenir, sabit boyuta çevrilip GPU (HARDWARE) bitmap olarak önbelleğe alınır.
 * - Sıralama Türkçe alfabeye göre yapılır (Ç, Ğ, İ, Ö, Ş, Ü doğru yerde).
 */
class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val pm: PackageManager = context.packageManager
    private val iconPx = (60 * context.resources.displayMetrics.density).roundToInt()
    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()
    private val collator: Collator =
        Collator.getInstance(Locale.forLanguageTag("tr-TR")).apply { strength = Collator.PRIMARY }

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.Default) {
        val activities = launcherApps.getActivityList(null, Process.myUserHandle())
            .filter { it.componentName.packageName != context.packageName }

        activities.map { info ->
            async {
                val key = info.componentName.flattenToString()
                val icon = iconCache.getOrPut(key) { loadIcon(info) }
                val label = info.label?.toString()?.trim().orEmpty()
                    .ifEmpty { info.componentName.packageName }
                AppInfo(label, info.componentName, icon)
            }
        }.awaitAll().sortedWith(compareBy(collator) { it.label })
    }

    fun invalidate(packageName: String) {
        iconCache.keys.removeIf { it.startsWith("$packageName/") }
    }

    private fun loadIcon(info: LauncherActivityInfo): ImageBitmap {
        val drawable = try {
            info.getIcon(context.resources.displayMetrics.densityDpi)
        } catch (e: Exception) {
            pm.defaultActivityIcon
        }
        val bmp = drawable.toBitmap(iconPx, iconPx, Bitmap.Config.ARGB_8888)
        val fast = try {
            bmp.copy(Bitmap.Config.HARDWARE, false) ?: bmp
        } catch (e: Exception) {
            bmp
        }
        return fast.asImageBitmap()
    }

    /** İlk açılışta iOS tarzı dock: Telefon, Mesajlar, Tarayıcı, Kamera. */
    fun defaultDock(apps: List<AppInfo>): List<String> {
        val byPkg = apps.groupBy { it.packageName }

        fun resolve(intent: Intent): String? = try {
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.takeIf { it != "android" }
        } catch (e: Exception) {
            null
        }

        val slots = listOf(
            Intent(Intent.ACTION_DIAL) to listOf(
                "com.google.android.dialer", "com.android.contacts", "com.android.dialer"
            ),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")) to listOf(
                "com.google.android.apps.messaging", "com.android.mms"
            ),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
                .addCategory(Intent.CATEGORY_BROWSABLE) to listOf(
                "com.android.chrome", "com.mi.globalbrowser", "com.android.browser", "org.mozilla.firefox"
            ),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA) to listOf(
                "com.android.camera", "com.google.android.GoogleCamera"
            ),
        )

        val result = LinkedHashSet<String>()
        for ((intent, fallbacks) in slots) {
            val pkg = (listOfNotNull(resolve(intent)) + fallbacks)
                .firstOrNull { byPkg.containsKey(it) } ?: continue
            byPkg[pkg]?.firstOrNull()?.let { result += it.key }
        }
        for (app in apps) {
            if (result.size >= 4) break
            result += app.key
        }
        return result.toList()
    }
}
