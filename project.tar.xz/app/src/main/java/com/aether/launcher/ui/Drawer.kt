package com.aether.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.launcher.data.AppInfo
import android.graphics.Rect as AndroidRect

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    suggestions: List<AppInfo>,
    query: String,
    onQueryChange: (String) -> Unit,
    isOpen: Boolean,
    progress: () -> Float,
    heightPx: Float,
    onDrag: (Float) -> Unit,
    onSettle: (Float) -> Unit,
    onLaunch: (AppInfo, AndroidRect?) -> Unit,
    menuItems: (AppInfo) -> List<AppMenuItem>,
    onWebSearch: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val accent = LocalAccent.current
    val gridState = rememberLazyGridState()
    val currentProgress by rememberUpdatedState(progress)
    val currentDrag by rememberUpdatedState(onDrag)
    val currentSettle by rememberUpdatedState(onSettle)

    LaunchedEffect(isOpen) { if (!isOpen) gridState.scrollToItem(0) }

    // Liste en üstteyken aşağı çekince çekmece kapanır
    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (currentProgress() < 0.999f && available.y < 0f) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f) {
                    currentDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (currentProgress() < 0.999f) {
                    currentSettle(available.y)
                    return available
                }
                return Velocity.Zero
            }
        }
    }

    val results = remember(query, apps) { filterApps(apps, query) }
    val sections = remember(apps) { apps.groupBy { sectionKey(it.label) } }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    val submit: () -> Unit = {
        val first = results.firstOrNull()
        if (first != null) onLaunch(first, null)
        else if (query.isNotBlank()) onWebSearch(query.trim())
    }

    Box(
        Modifier
            .fillMaxSize()
            // Kapalıyken ekran dışına it: dokunuşları engellemez
            .offset { IntOffset(0, if (progress() <= 0.001f) heightPx.toInt() * 2 else 0) }
            .graphicsLayer {
                val p = progress()
                alpha = p
                translationY = (1f - p) * heightPx * 0.35f
            }
            .background(Brush.verticalGradient(listOf(Color(0x9905060F), Color(0xE605060F))))
            .pointerInput(Unit) {
                awaitPointerEventScope { while (true) awaitPointerEvent() }
            }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .draggable(
                        state = rememberDraggableState { currentDrag(it) },
                        orientation = Orientation.Vertical,
                        onDragStopped = { v -> currentSettle(v) },
                    )
                    .padding(horizontal = 18.dp)
            ) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(top = 10.dp, bottom = 14.dp)
                        .size(width = 44.dp, height = 5.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.35f))
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SearchField(query, onQueryChange, submit, Modifier.weight(1f))
                    Box(
                        Modifier
                            .size(50.dp)
                            .glass(CircleShape, accent)
                            .clickable(onClick = onOpenSettings),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Ayarlar", tint = Color.White)
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                state = gridState,
                modifier = Modifier.weight(1f).fillMaxWidth().nestedScroll(connection),
                contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 14.dp, bottom = 32.dp + navBottom),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                if (query.isBlank()) {
                    if (suggestions.isNotEmpty()) {
                        sectionHeader("ÖNERİLEN", "h__suggested")
                        items(suggestions, key = { "s_" + it.key }) { app ->
                            GridCell { AppIcon(app, onLaunch, menuItems) }
                        }
                    }
                    sections.forEach { (letter, list) ->
                        sectionHeader(letter, "h_$letter")
                        items(list, key = { it.key }) { app ->
                            GridCell { AppIcon(app, onLaunch, menuItems) }
                        }
                    }
                } else if (results.isEmpty()) {
                    item(key = "web", span = { GridItemSpan(maxLineSpan) }) {
                        WebSearchButton(query.trim()) { onWebSearch(query.trim()) }
                    }
                } else {
                    items(results, key = { "r_" + it.key }) { app ->
                        GridCell { AppIcon(app, onLaunch, menuItems) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridCell(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { content() }
}

@OptIn(ExperimentalTextApi::class)
private fun LazyGridScope.sectionHeader(title: String, key: String) {
    item(key = key, span = { GridItemSpan(maxLineSpan) }) {
        val accent = LocalAccent.current
        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = title,
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(accent.primary, accent.secondary)),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                ),
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(1.dp)
                    .background(Brush.horizontalGradient(listOf(accent.primary.copy(alpha = 0.5f), Color.Transparent)))
            )
        }
    }
}

@Composable
private fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalAccent.current
    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(accent.primary),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .glass(RoundedCornerShape(25.dp), accent)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = accent.primary)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text("Uygulama ara…", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                    }
                    inner()
                }
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close,
                        contentDescription = "Temizle",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.clip(CircleShape).clickable { onQueryChange("") }.padding(4.dp),
                    )
                }
            }
        },
    )
}

@Composable
private fun WebSearchButton(query: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp)
            .glass(RoundedCornerShape(22.dp), accent)
            .clickable(onClick = onClick)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, contentDescription = null, tint = accent.primary)
        Spacer(Modifier.width(12.dp))
        Text("\"$query\" için web'de ara", color = Color.White, fontSize = 15.sp)
    }
}

private fun sectionKey(label: String): String {
    val c = label.trim().firstOrNull() ?: return "#"
    return if (c.isLetter()) c.toString().uppercase(TR) else "#"
}

private fun initials(label: String): String =
    label.split(' ', '-', '_', '.').filter { it.isNotEmpty() }.joinToString("") { it.take(1) }

private fun filterApps(apps: List<AppInfo>, query: String): List<AppInfo> {
    val q = query.trim().lowercase(TR)
    if (q.isEmpty()) return emptyList()
    return apps
        .filter {
            val l = it.label.lowercase(TR)
            l.contains(q) || initials(l).startsWith(q) || it.packageName.contains(q)
        }
        .sortedBy { if (it.label.lowercase(TR).startsWith(q)) 0 else 1 }
}
