package com.aether.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

/**
 * 2050 "nebula" arka planı: renk bulutları, yıldızlar ve ufukta neon perspektif ızgara.
 * drawWithCache ile bir kez hesaplanır; animasyon yok, pil dostu.
 */
@Composable
fun NebulaBackground(accent: AccentPalette, modifier: Modifier = Modifier) {
    Spacer(
        modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val base = Brush.verticalGradient(
                    listOf(Color(0xFF04050D), Color(0xFF0A0920), Color(0xFF05040E))
                )
                val blob1 = Brush.radialGradient(
                    listOf(accent.secondary.copy(alpha = 0.55f), Color.Transparent),
                    center = Offset(w * 0.1f, h * 0.18f), radius = w * 0.9f,
                )
                val blob2 = Brush.radialGradient(
                    listOf(accent.primary.copy(alpha = 0.36f), Color.Transparent),
                    center = Offset(w * 1.0f, h * 0.6f), radius = w * 0.85f,
                )
                val blob3 = Brush.radialGradient(
                    listOf(accent.tertiary.copy(alpha = 0.24f), Color.Transparent),
                    center = Offset(w * 0.3f, h * 0.98f), radius = w * 0.8f,
                )
                val rnd = Random(2050)
                val stars = List(90) {
                    Offset(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.72f) to (rnd.nextFloat() * 1.6f + 0.4f)
                }
                val horizon = h * 0.74f
                val glow = Brush.verticalGradient(
                    listOf(Color.Transparent, accent.primary.copy(alpha = 0.20f), Color.Transparent),
                    startY = horizon - 70f, endY = horizon + 70f,
                )

                onDrawBehind {
                    drawRect(base)
                    drawRect(blob1)
                    drawRect(blob2)
                    drawRect(blob3)
                    stars.forEach { (o, r) ->
                        drawCircle(Color.White.copy(alpha = (0.2f + r * 0.22f).coerceAtMost(0.75f)), r, o)
                    }
                    // Ufuk parıltısı
                    drawRect(glow, topLeft = Offset(0f, horizon - 70f), size = Size(w, 140f))
                    // Yatay ızgara çizgileri (yaklaştıkça açılır)
                    for (i in 0 until 14) {
                        val t = i / 13f
                        val y = horizon + (h - horizon) * t * t
                        drawLine(
                            accent.primary.copy(alpha = 0.04f + 0.12f * t),
                            Offset(0f, y), Offset(w, y), strokeWidth = 1.5f,
                        )
                    }
                    // Kaybolma noktasına giden dikey çizgiler
                    for (i in -10..10) {
                        drawLine(
                            accent.primary.copy(alpha = 0.10f),
                            Offset(w / 2f + i * w * 0.02f, horizon),
                            Offset(w / 2f + i * w * 0.16f, h),
                            strokeWidth = 1.2f,
                        )
                    }
                }
            }
    )
}

/** Sistem duvar kâğıdı açıkken yazıların okunması için hafif karartma. */
@Composable
fun WallpaperScrim(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.40f), Color.Transparent, Color.Black.copy(alpha = 0.45f))
                )
            )
    )
}
