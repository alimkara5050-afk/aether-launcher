package com.aether.launcher.ui

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.aether.launcher.LauncherViewModel
import com.aether.launcher.data.AppInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import kotlin.math.abs
import android.graphics.Rect as AndroidRect

private const val COLS = 4
private const val ROWS = 5
private const val APPS_PER_PAGE = COLS * ROWS
private val DOCK_RESERVED = 100.dp

class LauncherActions(
    val launch: (AppInfo, AndroidRect?) -> Unit,
    val appInfo: (AppInfo) -> Unit,
    val uninstall: (AppInfo) -> Unit,
    val expandNotifications: () -> Unit,
    val webSearch: (String) -> Unit,
    val openClock: () -> Unit,
    val openHomeSettings: () -> Unit,
    val openWallpaperPicker: () -> Unit,
    val toast: (String) -> Unit,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherRoot(vm: LauncherViewModel, homeTick: Int, actions: LauncherActions) {
    val accent = Palettes[vm.accentIndex.coerceIn(0, Palettes.lastIndex)]
    AetherTheme(accent) {
        val scope = rememberCoroutineScope()
        val focusManager = LocalFocusManager.current
        val keyboard = LocalSoftwareKeyboardController.current

        // 1 = çekmece kapalı, 0 = tamamen açık
        var drawerPos by remember { mutableFloatStateOf(1f) }
        var settleJob by remember { mutableStateOf<Job?>(null) }
        var query by remember { mutableStateOf("") }
        var showSettings by remember { mutableStateOf(false) }
        val drawerOpen by remember { derivedStateOf { drawerPos < 0.999f } }

        val homeApps = vm.homeApps
        val pages = remember(homeApps) { homeApps.chunked(APPS_PER_PAGE) }
        val pagerState = rememberPagerState { pages.size.coerceAtLeast(1) }

        val menuFor: (AppInfo) -> List<AppMenuItem> = remember(vm, actions) {
            { app ->
                listOf(
                    AppMenuItem(if (vm.isDocked(app)) "Dock'tan kaldır" else "Dock'a sabitle", Icons.Rounded.Star) {
                        if (!vm.toggleDock(app)) actions.toast("Dock dolu — en fazla ${LauncherViewModel.MAX_DOCK} uygulama")
                    },
                    AppMenuItem("Uygulama bilgisi", Icons.Rounded.Info) { actions.appInfo(app) },
                    AppMenuItem("Kaldır", Icons.Rounded.Delete) { actions.uninstall(app) },
                )
            }
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

            fun closeCleanup() {
                query = ""
                keyboard?.hide()
                focusManager.clearFocus()
            }

            fun settle(velocity: Float) {
                settleJob?.cancel()
                val target = when {
                    velocity < -900f -> 0f
                    velocity > 900f -> 1f
                    drawerPos < 0.5f -> 0f
                    else -> 1f
                }
                settleJob = scope.launch {
                    animate(
                        initialValue = drawerPos,
                        targetValue = target,
                        initialVelocity = velocity / heightPx,
                        animationSpec = spring(dampingRatio = 0.9f, stiffness = 420f),
                    ) { v, _ -> drawerPos = v.coerceIn(0f, 1f) }
                    drawerPos = target
                    if (target == 1f) closeCleanup()
                }
            }

            fun drag(dy: Float) {
                settleJob?.cancel()
                drawerPos = (drawerPos + dy / heightPx).coerceIn(0f, 1f)
            }

            val launch: (AppInfo, AndroidRect?) -> Unit = { app, rect ->
                actions.launch(app, rect)
                if (drawerOpen) {
                    scope.launch {
                        delay(400)
                        settleJob?.cancel()
                        drawerPos = 1f
                        closeCleanup()
                    }
                }
            }

            LaunchedEffect(homeTick) {
                if (homeTick == 0) return@LaunchedEffect
                showSettings = false
                if (drawerOpen) settle(2500f)
                else if (pagerState.currentPage != 0) pagerState.animateScrollToPage(0)
            }

            BackHandler { if (drawerOpen) settle(2500f) }

            // ── Arka plan ──
            if (vm.useSystemWallpaper) WallpaperScrim() else NebulaBackground(accent)

            // ── Ana ekran ──
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = 1f - drawerPos
                        val s = 1f - 0.08f * p
                        scaleX = s
                        scaleY = s
                        alpha = 1f - 0.75f * p
                        renderEffect = if (p > 0.01f && Build.VERSION.SDK_INT >= 31) {
                            BlurEffect(40f * p, 40f * p, TileMode.Decal)
                        } else null
                    }
                    .pointerInput(heightPx) {
                        val tracker = VelocityTracker()
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = {
                                tracker.resetTracking()
                                total = 0f
                            },
                            onDragEnd = {
                                val v = tracker.calculateVelocity().y
                                if (drawerPos < 0.999f) settle(v)
                                else if (total > 120f) actions.expandNotifications()
                            },
                            onDragCancel = { if (drawerPos < 0.999f) settle(0f) },
                        ) { change, dy ->
                            change.consume()
                            tracker.addPosition(change.uptimeMillis, change.position)
                            total += dy
                            if (dy < 0f || drawerPos < 0.999f) drag(dy)
                        }
                    }
            ) {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    HomeHeader(
                        onClick = actions.openClock,
                        onLongPress = { showSettings = true },
                        modifier = Modifier.padding(start = 26.dp, end = 26.dp, top = 18.dp, bottom = 4.dp),
                    )
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                    ) { page ->
                        AppGridPage(
                            apps = pages.getOrElse(page) { emptyList() },
                            showLabels = vm.showLabels,
                            onLaunch = launch,
                            menuItems = menuFor,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    // Hafif 3B küp geçişi
                                    val offset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                                    val a = abs(offset).coerceIn(0f, 1f)
                                    transformOrigin = TransformOrigin(if (offset > 0f) 1f else 0f, 0.5f)
                                    rotationY = -offset * 40f
                                    cameraDistance = 16f * density
                                    alpha = 1f - 0.4f * a
                                },
                        )
                    }
                    PageDots(
                        count = pagerState.pageCount,
                        current = pagerState.currentPage,
                        modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp),
                    )
                    Spacer(Modifier.navigationBarsPadding().height(DOCK_RESERVED))
                }

                Dock(
                    apps = vm.dockApps,
                    onLaunch = launch,
                    menuItems = menuFor,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 14.dp),
                )
            }

            // ── Uygulama çekmecesi (her zaman hazır → anında açılır) ──
            AppDrawer(
                apps = vm.apps,
                suggestions = vm.suggestions,
                query = query,
                onQueryChange = { query = it },
                isOpen = drawerOpen,
                progress = { 1f - drawerPos },
                heightPx = heightPx,
                onDrag = { drag(it) },
                onSettle = { settle(it) },
                onLaunch = launch,
                menuItems = menuFor,
                onWebSearch = actions.webSearch,
                onOpenSettings = { showSettings = true },
            )

            if (showSettings) {
                SettingsSheet(vm = vm, actions = actions, onDismiss = { showSettings = false })
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalTextApi::class)
@Composable
private fun HomeHeader(onClick: () -> Unit, onLongPress: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val accent = LocalAccent.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var battery by remember { mutableIntStateOf(readBattery(context).first) }
    var charging by remember { mutableStateOf(readBattery(context).second) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                now = System.currentTimeMillis()
                val (level, isCharging) = readBattery(context)
                battery = level
                charging = isCharging
                delay(60_000L - now % 60_000L + 30L)
            }
        }
    }

    val is24 = DateFormat.is24HourFormat(context)
    val timeText = remember(now, is24) { SimpleDateFormat(if (is24) "HH:mm" else "h:mm", TR).format(Date(now)) }
    val dateText = remember(now) { SimpleDateFormat("EEEE · d MMMM", TR).format(Date(now)).uppercase(TR) }
    val greeting = remember(now) {
        when (Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Günaydın"
            in 12..17 -> "İyi günler"
            in 18..22 -> "İyi akşamlar"
            else -> "İyi geceler"
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onLongClick = onLongPress,
                onClick = onClick,
            )
    ) {
        Text(
            text = dateText,
            color = Color.White.copy(alpha = 0.72f),
            fontSize = 13.sp,
            letterSpacing = 3.sp,
            fontWeight = FontWeight.Medium,
        )
        Text(
            text = timeText,
            style = TextStyle(
                brush = Brush.linearGradient(listOf(Color.White, accent.primary, accent.secondary)),
                fontSize = 92.sp,
                lineHeight = 98.sp,
                fontWeight = FontWeight.Thin,
                letterSpacing = (-3).sp,
            ),
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoChip {
                BatteryGlyph(level = battery, charging = charging)
                Text("%$battery", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            InfoChip {
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(accent.primary, accent.secondary)))
                )
                Text(greeting, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

private fun readBattery(context: Context): Pair<Int, Boolean> {
    val bm = context.getSystemService(BatteryManager::class.java) ?: return 0 to false
    val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    return level to bm.isCharging
}

@Composable
private fun InfoChip(content: @Composable RowScope.() -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier
            .glass(RoundedCornerShape(50), accent, 0.8f)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        content = content,
    )
}

@Composable
private fun BatteryGlyph(level: Int, charging: Boolean) {
    val accent = LocalAccent.current
    val fill = when {
        charging -> Brush.horizontalGradient(listOf(Color(0xFF00FFA3), accent.primary))
        level <= 20 -> SolidColor(Color(0xFFFF4D6D))
        else -> Brush.horizontalGradient(listOf(accent.primary, accent.secondary))
    }
    Canvas(Modifier.size(width = 22.dp, height = 11.dp)) {
        val stroke = 1.2.dp.toPx()
        val nub = 2.dp.toPx()
        val bodyW = size.width - nub
        drawRoundRect(
            color = Color.White.copy(alpha = 0.8f),
            size = Size(bodyW, size.height),
            cornerRadius = CornerRadius(3.dp.toPx()),
            style = Stroke(stroke),
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.8f),
            topLeft = Offset(bodyW + 0.5f, size.height * 0.3f),
            size = Size(nub - 0.5f, size.height * 0.4f),
            cornerRadius = CornerRadius(1.dp.toPx()),
        )
        val inset = stroke * 1.8f
        drawRoundRect(
            brush = fill,
            topLeft = Offset(inset, inset),
            size = Size(((bodyW - inset * 2) * level / 100f).coerceAtLeast(0f), size.height - inset * 2),
            cornerRadius = CornerRadius(1.5.dp.toPx()),
        )
    }
}

@Composable
private fun AppGridPage(
    apps: List<AppInfo>,
    showLabels: Boolean,
    onLaunch: (AppInfo, AndroidRect?) -> Unit,
    menuItems: (AppInfo) -> List<AppMenuItem>,
    modifier: Modifier = Modifier,
) {
    Column(modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.SpaceEvenly) {
        for (row in 0 until ROWS) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until COLS) {
                    val app = apps.getOrNull(row * COLS + col)
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        if (app != null) {
                            key(app.key) {
                                AppIcon(app, onLaunch, menuItems, showLabel = showLabels)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    if (count <= 1) {
        Spacer(modifier.height(6.dp))
        return
    }
    val accent = LocalAccent.current
    Row(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { i ->
            val active = i == current
            val width by animateDpAsState(if (active) 22.dp else 6.dp, label = "dot")
            Box(
                Modifier
                    .size(width = width, height = 6.dp)
                    .clip(CircleShape)
                    .background(
                        if (active) Brush.horizontalGradient(listOf(accent.primary, accent.secondary))
                        else SolidColor(Color.White.copy(alpha = 0.35f))
                    )
            )
        }
    }
}

/** iOS tarzı, ortalanmış, yüzen cam dock. */
@Composable
private fun Dock(
    apps: List<AppInfo>,
    onLaunch: (AppInfo, AndroidRect?) -> Unit,
    menuItems: (AppInfo) -> List<AppMenuItem>,
    modifier: Modifier = Modifier,
) {
    if (apps.isEmpty()) return
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(34.dp)
    Row(
        modifier
            .drawBehind {
                // Dock altındaki neon parıltı
                drawOval(
                    brush = Brush.radialGradient(
                        listOf(accent.primary.copy(alpha = 0.32f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 0.9f),
                        radius = size.width * 0.65f,
                    ),
                    topLeft = Offset(-size.width * 0.15f, size.height * 0.1f),
                    size = Size(size.width * 1.3f, size.height * 1.5f),
                )
            }
            .glass(shape, accent, 1.25f)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.forEach { app ->
            key(app.key) {
                AppIcon(app, onLaunch, menuItems, iconSize = 56.dp, showLabel = false)
            }
        }
    }
}
