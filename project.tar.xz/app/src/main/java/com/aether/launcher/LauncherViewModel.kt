package com.aether.launcher

import android.app.Application
import android.content.Context
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aether.launcher.data.AppInfo
import com.aether.launcher.data.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppRepository(application)
    private val prefs = application.getSharedPreferences("aether_prefs", Context.MODE_PRIVATE)
    private val launcherApps = application.getSystemService(LauncherApps::class.java)
    private var loadJob: Job? = null

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set

    /** Dock'taki uygulamaların anahtarları (sıralı). */
    val dock = mutableStateListOf<String>()

    /** Akıllı öneriler için açılma sayıları. */
    private val usage = mutableStateMapOf<String, Int>()

    var accentIndex by mutableIntStateOf(prefs.getInt(KEY_ACCENT, 0))
        private set
    var useSystemWallpaper by mutableStateOf(prefs.getBoolean(KEY_WALLPAPER, false))
        private set
    var showLabels by mutableStateOf(prefs.getBoolean(KEY_LABELS, true))
        private set

    private val appsByKey by derivedStateOf { apps.associateBy { it.key } }
    val dockApps: List<AppInfo> by derivedStateOf { dock.mapNotNull { appsByKey[it] } }
    val homeApps: List<AppInfo> by derivedStateOf {
        val pinned = dock.toSet()
        apps.filter { it.key !in pinned }
    }
    val suggestions: List<AppInfo> by derivedStateOf {
        usage.entries.sortedByDescending { it.value }
            .mapNotNull { appsByKey[it.key] }
            .take(4)
    }

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = changed(packageName)
        override fun onPackageAdded(packageName: String, user: UserHandle) = changed(packageName)
        override fun onPackageChanged(packageName: String, user: UserHandle) = changed(packageName)
        override fun onPackagesAvailable(packageNames: Array<String>, user: UserHandle, replacing: Boolean) =
            changed(*packageNames)
        override fun onPackagesUnavailable(packageNames: Array<String>, user: UserHandle, replacing: Boolean) =
            changed(*packageNames)
    }

    init {
        prefs.getString(KEY_DOCK, null)?.takeIf { it.isNotEmpty() }?.let { dock.addAll(it.split(SEP)) }
        prefs.all.forEach { (k, v) -> if (k.startsWith(USAGE_PREFIX) && v is Int) usage[k.removePrefix(USAGE_PREFIX)] = v }
        launcherApps.registerCallback(callback, Handler(Looper.getMainLooper()))
        refresh()
    }

    private fun changed(vararg packages: String) {
        packages.forEach(repo::invalidate)
        refresh()
    }

    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val list = repo.loadApps()
            apps = list
            if (!prefs.getBoolean(KEY_DOCK_SET, false)) {
                dock.clear()
                dock.addAll(repo.defaultDock(list))
                persistDock()
            }
        }
    }

    fun isDocked(app: AppInfo): Boolean = app.key in dock

    /** false dönerse dock dolu demektir. */
    fun toggleDock(app: AppInfo): Boolean {
        if (app.key in dock) {
            dock.remove(app.key)
        } else {
            if (dock.size >= MAX_DOCK) return false
            dock.add(app.key)
        }
        persistDock()
        return true
    }

    fun recordLaunch(app: AppInfo) {
        val n = (usage[app.key] ?: 0) + 1
        usage[app.key] = n
        prefs.edit().putInt(USAGE_PREFIX + app.key, n).apply()
    }

    fun updateAccent(index: Int) {
        accentIndex = index
        prefs.edit().putInt(KEY_ACCENT, index).apply()
    }

    fun updateWallpaper(enabled: Boolean) {
        useSystemWallpaper = enabled
        prefs.edit().putBoolean(KEY_WALLPAPER, enabled).apply()
    }

    fun updateLabels(enabled: Boolean) {
        showLabels = enabled
        prefs.edit().putBoolean(KEY_LABELS, enabled).apply()
    }

    private fun persistDock() {
        prefs.edit()
            .putString(KEY_DOCK, dock.joinToString(SEP))
            .putBoolean(KEY_DOCK_SET, true)
            .apply()
    }

    override fun onCleared() {
        launcherApps.unregisterCallback(callback)
        super.onCleared()
    }

    companion object {
        const val MAX_DOCK = 5
        private const val SEP = "|"
        private const val USAGE_PREFIX = "u_"
        private const val KEY_DOCK = "dock"
        private const val KEY_DOCK_SET = "dock_set"
        private const val KEY_ACCENT = "accent"
        private const val KEY_WALLPAPER = "wallpaper"
        private const val KEY_LABELS = "labels"
    }
}
